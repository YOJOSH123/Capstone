using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Josh_Nick_Capstone_Website.Pages
{
    public class ProposalModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
