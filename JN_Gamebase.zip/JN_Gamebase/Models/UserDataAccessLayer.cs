﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

using JN_Gamebase.Pages;

namespace JN_Gamebase.Models
{
    public class UserDataAccessLayer
    {
        string connectionString;

        private readonly IConfiguration _configuration;

        public UserDataAccessLayer(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public void Create(User users)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = "INSERT Into Users (Email, Username, Password) VALUES (@Email, @Username, @Password);";
                users.Feedback = "";

                try
                {
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.CommandType = CommandType.Text;
                        command.Parameters.AddWithValue("@Email", users.Email);
                        command.Parameters.AddWithValue("@Username", users.Username);
                        command.Parameters.AddWithValue("@Password", users.Password);

                        connection.Open();

                        users.Feedback = command.ExecuteNonQuery().ToString() + " Record Added";

                        connection.Close();
                    }
                }
                catch (Exception err)
                {
                    users.Feedback = "Error: " + err.Message;
                }

            }
        }

        public IEnumerable<User> GetUserLogin(User tUser)
        {
            List<User> lstUser = new List<User>();

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string strSQL = "SELECT TOP 1 * FROM Users WHERE Email = @Email AND Password = @Password;";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@Email", tUser.Email);
                    cmd.Parameters.AddWithValue("@Password", tUser.Password);

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        User tMatch = new User();

                        tMatch.UserId = Convert.ToInt32(rdr["UserId"]);
                        tMatch.Email = rdr["Email"].ToString();
                        tMatch.Password = rdr["Password"].ToString();

                        lstUser.Add(tMatch);
                    }

                    con.Close();
                }
            }
            catch (Exception err)
            {

            }
            return lstUser;
        }
    }
}
