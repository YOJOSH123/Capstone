﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace JN_Gamebase.Models
{
    public class Games
    {
        [Required]
        public int GameId { get; set; }

        [Required, StringLength(100)]
        public String GameTitle { get; set; }

        [Required, StringLength(100)]
        public String Developer { get; set; }

        [Required]
        [Display(Name = "Original Release Date")]
        [DataType(DataType.DateTime), DisplayFormat(DataFormatString = "{0:MM/dd/yyyy hh:mm:ss tt}", ApplyFormatInEditMode = true)]
        public DateTime ReleaseDate { get; set; }

        [Required, StringLength(100)]
        public String Genre { get; set; }

        [Required, StringLength(5)]
        public String ESRB { get; set; }

        [Required]
        public String Descrpition { get; set; }

        [Required]
        [Display(Name = "Original Date Added")]
        [DataType(DataType.DateTime), DisplayFormat(DataFormatString = "{0:MM/dd/yyyy hh:mm:ss tt}", ApplyFormatInEditMode = true)]
        public DateTime DateAdded { get; set; }

        public String Feedback { get; set; }



        private string GetConnected()
        {
            return @"Server=sql.neit.edu,4500; Database=se265_NickJosh; User ID=NickJosh; Password=PHPStillRocks;";
        }
        public DataSet SearchGames_DS(string strGameTitle, string strGenre)
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT GameId, GameTitle, Developer, Genre, ESRB, ReleaseDate, Description, DateAdded FROM Games WHERE 0=0";

            if (strGameTitle.Length > 0)
            {
                strSQL += " AND GameTitle LIKE @GameTitle";
                comm.Parameters.AddWithValue("@GameTitle", "%" + strGameTitle + "%");
            }
            if (strGenre.Length > 0)
            {
                strSQL += " AND AuthorLast LIKE @AuthorLast";
                comm.Parameters.AddWithValue("@AuthorLast", "%" + strGenre + "%");
            }

            SqlConnection conn = new SqlConnection();
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "Games_Temp");
            conn.Close();

            return ds;
        }

        public SqlDataReader SearchGames_DR(String strGameTitle, String strGenre)
        {
            SqlDataReader dr;
            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT GameId, GameTitle, Developer, Genre, ESRB, ReleaseDate, Description, DateAdded FROM Games WHERE 0=0";

            if (strGameTitle.Length > 0)
            {
                strSQL += " AND GameTitle LIKE @GameTitle";
                comm.Parameters.AddWithValue("@GameTitle", "%" + strGameTitle + "%");
            }
            if (strGenre.Length > 0)
            {
                strSQL += " AND Genre LIKE @Genre";
                comm.Parameters.AddWithValue("@Genre", "%" + strGenre + "%");
            }

            SqlConnection conn = new SqlConnection();
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;

            conn.Open();
            dr = comm.ExecuteReader();
            return dr;
        }
    }
}
