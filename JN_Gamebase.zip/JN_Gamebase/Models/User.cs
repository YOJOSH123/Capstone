﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel.DataAnnotations;

using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Session;

namespace JN_Gamebase.Models
{
    public class User
    {
        [Required]
        public int UserId { get; set; }

       
        [EmailAddress]
        [Display(Name = "Email")]
        public String Email { get; set; }

        [Display(Name = "Username")]
        public String Username { get; set; }

        [Required, StringLength(50)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public String Password { get; set; }

        public String Feedback { get; set; }
    }
}
