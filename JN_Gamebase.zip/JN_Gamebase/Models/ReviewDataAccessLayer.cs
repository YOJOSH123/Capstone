﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

namespace JN_Gamebase.Models
{
    public class ReviewDataAccessLayer
    {
        string connectionString;

        private readonly IConfiguration _configuration;

        public ReviewDataAccessLayer(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public void Create(Reviews nreview)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = "INSERT Into Reviews (RatingScore, Review) VALUES (@UserId, @GameId, @RatingScore, @Review);";
                nreview.Feedback = "";

                try
                {
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.CommandType = CommandType.Text;
                        command.Parameters.AddWithValue("@UserId", nreview.UserId);
                        command.Parameters.AddWithValue("@GameId", nreview.GameId);
                        command.Parameters.AddWithValue("@RatingScore", nreview.RatingScore);
                        command.Parameters.AddWithValue("@Review", nreview.Review);

                        connection.Open();

                        nreview.Feedback = command.ExecuteNonQuery().ToString() + " Record Added";

                        connection.Close();
                    }
                }
                catch (Exception err)
                {
                    nreview.Feedback = "Error: " + err.Message;
                }

            }
        }
    }
}
