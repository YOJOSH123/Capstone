﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

namespace JN_Gamebase.Models
{
    public class PlatformDataAccessLayer
    {
        string connectionString;

        private readonly IConfiguration _configuration;

        public void Create(Platform platforms)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = "INSERT Into Platforms (GameId, PlatformName, Price, ReleaseDate) VALUES (@GameId, @PlatformName, @Price, @ReleaseDate);";
                platforms.Feedback = "";

                try
                {
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.CommandType = CommandType.Text;
                        command.Parameters.AddWithValue("@GameId", platforms.GameId);
                        command.Parameters.AddWithValue("@PlatformName", platforms.PlatformName);
                        command.Parameters.AddWithValue("@Price", platforms.Price);
                        command.Parameters.AddWithValue("@ReleaseDate", platforms.ReleaseDate);

                        connection.Open();

                        platforms.Feedback = command.ExecuteNonQuery().ToString() + " Record Added";

                        connection.Close();
                    }
                }
                catch (Exception err)
                {
                    platforms.Feedback = "Error: " + err.Message;
                }

            }
        }
    }
}
