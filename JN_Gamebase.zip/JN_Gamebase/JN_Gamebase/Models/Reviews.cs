﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel.DataAnnotations;

namespace JN_Gamebase.Models
{
    public class Reviews
    {
        [Required]
        public int ReviewId { get; set; }

        [Required]
        public int GameId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        public float RatingScore { get; set; }

        [Required]
        public string Review { get; set;  }

        public String Feedback { get; set; }
    }
}
