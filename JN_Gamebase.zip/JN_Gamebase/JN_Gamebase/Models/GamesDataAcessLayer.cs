﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;
using JN_Gamebase.App_Code;

namespace JN_Gamebase.Models
{
    public class GamesDataAcessLayer
    {
        string connectionString;

        private readonly IConfiguration _configuration;

        public GamesDataAcessLayer(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public void Create(Games game)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = "INSERT Into Games (GameTitle, Developer, Genre, ESRB, ReleaseDate, DateAdded, Description) VALUES (@GameTitle, @Developer, @Genre, @ESRB, @ReleaseDate, @DateAdded, @Description);";
                game.Feedback = "";

                try
                {
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.CommandType = CommandType.Text;
                        command.Parameters.AddWithValue("@GameTitle", game.GameTitle);
                        command.Parameters.AddWithValue("@Developer", game.Developer);
                        command.Parameters.AddWithValue("@Genre", game.Genre);
                        command.Parameters.AddWithValue("@ESRB", game.ESRB);
                        command.Parameters.AddWithValue("@ReleaseDate", game.ReleaseDate);
                        command.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", game.Descrpition);

                        connection.Open();

                        game.Feedback = command.ExecuteNonQuery().ToString() + " Record Added";

                        connection.Close();
                    }
                }
                catch (Exception err)
                {
                    game.Feedback = "Error: " + err.Message;
                }

            }
        }

        public IEnumerable<Games> GetActiveRecords()
        {
            List<Games> lstGm = new List<Games>();

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string strSQL = "SELECT * FROM Games ORDER BY DateReleased;";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.CommandType = CommandType.Text;

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        Games game = new Games();

                        game.GameID = Convert.ToInt32(rdr["GameID"]);
                        game.GameTitle = rdr["GameTitle"].ToString();
                        game.Developer = rdr["Developer"].ToString();
                        game.Genre = rdr["Genre"].ToString();
                        game.ESRB = rdr["ERSB"].ToString();
                        game.ReleaseDate = DateTime.Parse(rdr["ReleaseDate"].ToString());
                        game.DateAdded = DateTime.Parse(rdr["DateAdded"].ToString());
                        game.Descrpition = rdr["Description"].ToString();

                        lstGm.Add(game);
                    }
                    con.Close();
                }
            }
            catch (Exception err)
            {

            }
            return lstGm;
        }
    }
}
