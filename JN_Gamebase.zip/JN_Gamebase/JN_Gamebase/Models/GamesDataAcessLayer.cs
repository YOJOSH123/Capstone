﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

namespace JN_Gamebase.Models
{
    public class GamesDataAcessLayer
    {
        string connectionString;

        private readonly IConfiguration _configuration;

        public GamesDataAcessLayer(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public void Create(Games game)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = "INSERT Into Games (GameTitle, Developer, Genre, ESRB, ReleaseDate, DateAdded, Description) VALUES (@GameTitle, @Developer, @Genre, @ESRB, @ReleaseDate, @DateAdded, @Description);";
                game.Feedback = "";

                try
                {
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.CommandType = CommandType.Text;
                        command.Parameters.AddWithValue("@GameTitle", game.GameTitle);
                        command.Parameters.AddWithValue("@Developer", game.Developer);
                        command.Parameters.AddWithValue("@Genre", game.Genre);
                        command.Parameters.AddWithValue("@ESRB", game.ESRB);
                        command.Parameters.AddWithValue("@ReleaseDate", game.ReleaseDate);
                        command.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                        command.Parameters.AddWithValue("@Description", game.Descrpition);

                        connection.Open();

                        game.Feedback = command.ExecuteNonQuery().ToString() + " Record Added";

                        connection.Close();
                    }
                }
                catch (Exception err)
                {
                    game.Feedback = "Error: " + err.Message;
                }

            }
        }

        public IEnumerable<Games> GetActiveRecords()
        {
            List<Games> lstGm = new List<Games>();

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string strSQL = "SELECT * FROM Games;";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.CommandType = CommandType.Text;

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        Games game = new Games();

                        game.GameId = Convert.ToInt32(rdr["GameId"]);
                        game.GameTitle = rdr["GameTitle"].ToString();
                        game.Developer = rdr["Developer"].ToString();
                        game.Genre = rdr["Genre"].ToString();
                        game.ESRB = rdr["ESRB"].ToString();
                        game.ReleaseDate = DateTime.Parse(rdr["ReleaseDate"].ToString());
                        game.DateAdded = DateTime.Parse(rdr["DateAdded"].ToString());
                        game.Descrpition = rdr["Description"].ToString();

                        lstGm.Add(game);
                    }
                    con.Close();
                }
            }
            catch (Exception err)
            {
                 
            }
            return lstGm;
        }

        public Games GetOneRecord(int? id)
        {
            Games game = new Games();

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string StrSQL = "SELECT * FROM Games WHERE GameId = @GameId;";
                    SqlCommand cmd = new SqlCommand(StrSQL, con);
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@GameId", id);

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        game.GameId = Convert.ToInt32(rdr["GameId"]);
                        game.GameTitle = rdr["GameTitle"].ToString();
                        game.Developer = rdr["Developer"].ToString();
                        game.Descrpition = rdr["Description"].ToString();
                        game.Genre = rdr["Genre"].ToString();
                        game.ESRB = rdr["ESRB"].ToString();
                        game.ReleaseDate = DateTime.Parse(rdr["ReleaseDate"].ToString());
                        game.DateAdded = DateTime.Parse(rdr["DateAdded"].ToString());
                    }
                    con.Close();
                }
            }
            catch (Exception err)
            {
                game.Feedback = "ERROR: " + err.Message;
            }
            return game;
        }

        public void UpdateGame(Games tGame)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand();

                    string strSQL;

                    strSQL = "UPDATE Games SET Developer = @Developer, Genre = @Genre, ESRB = @ERSB, ReleaseDate = @ReleaseDate, Description = @Description WHERE GameId = @GameId;";

                    cmd.CommandText = strSQL;
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@Developer", tGame.Developer);
                    cmd.Parameters.AddWithValue("@Genre", tGame.Genre);
                    cmd.Parameters.AddWithValue("@ERSB", tGame.ESRB);
                    cmd.Parameters.AddWithValue("@ReleaseDate", tGame.ReleaseDate);
                    cmd.Parameters.AddWithValue("@Description", tGame.Descrpition);

                    cmd.Parameters.AddWithValue("@GameId", tGame.GameId);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception err)
            {
                tGame.Feedback = "ERROR: " + err.Message;
            }
        }

        public Games DeleteGame(int? id)
        {
            Games game = new Games();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string strSQL = "DELETE FROM Games WHERE GameId = @GameId;";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@GameId", id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception err)
            {
                game.Feedback = "ERROR: " + err.Message;
            }
            return game;
        }

        public DataSet SearchEbooks_DS(string strGameTitle, string strGenre)
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT GameId, GameTitle, Developer, Genre, ESRB, ReleaseDate, Description, DateAdded FROM Games WHERE 0=0";

            if (strGameTitle.Length > 0)
            {
                strSQL += " AND GameTitle LIKE @GameTitle";
                comm.Parameters.AddWithValue("@GameTitle", "%" + strGameTitle + "%");
            }
            if (strGenre.Length > 0)
            {
                strSQL += " AND AuthorLast LIKE @AuthorLast";
                comm.Parameters.AddWithValue("@AuthorLast", "%" + strGenre + "%");
            }

            SqlConnection conn = new SqlConnection();
            string strConn = strSQL;
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "Games_Temp");
            conn.Close();

            return ds;
        }

        public SqlDataReader SearchGames_DR(String strGameTitle, String strGenre)
        {
            SqlDataReader dr;
            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT GameId, GameTitle, Developer, Genre, ESRB, ReleaseDate, Description, DateAdded FROM Games WHERE 0=0";

            if (strGameTitle.Length > 0)
            {
                strSQL += " AND GameTitle LIKE @GameTitle";
                comm.Parameters.AddWithValue("@GameTitle", "%" + strGameTitle + "%");
            }
            if (strGenre.Length > 0)
            {
                strSQL += " AND Genre LIKE @Genre";
                comm.Parameters.AddWithValue("@Genre", "%" + strGenre + "%");
            }

            SqlConnection conn = new SqlConnection();
            string strConn = strSQL;
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;

            conn.Open();
            dr = comm.ExecuteReader();
            return dr;
        }
    }
}
