﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Microsoft.Extensions.Configuration;

using JN_Gamebase.Models;
using JN_Gamebase.App_Code;

namespace JN_Gamebase.Pages
{
    public class AddGameModel : PageModel
    {
        [BindProperty]
        public Games tGame { get; set; }

        private readonly IConfiguration _configuration;
        public AddGameModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {

        }

        public IActionResult OnPost()
        {
            IActionResult temp;

            if (ModelState.IsValid == false)
            {
                temp = Page();
            }
            else
            {
                if (tGame is null == false)
                {
                    GamesDataAcessLayer factory = new GamesDataAcessLayer(_configuration);

                    factory.Create(tGame);
                }
                temp = Page();
            }

            return temp;
        }
    }
}