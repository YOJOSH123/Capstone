﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

using System.Data;
using System.Data.SqlClient;

using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Http;

namespace JN_Gamebase.Pages
{
    public class SearchModel : PageModel
    {
        private readonly IConfiguration _configuration;

        GamesDataAcessLayer factory;
        public List<Games> gm { get; set; }

        public SearchModel(IConfiguration configuration)
        {
            _configuration = configuration;
            factory = new GamesDataAcessLayer(_configuration);
        }

        public void OnGet()
        {
            gm = factory.GetActiveRecords().ToList();
        }

        [BindProperty]
        public Games tGame { get; set; }

        public IActionResult OnPost()
        {
            IActionResult temp;
            List<Games> lstGames = new List<Games>();

            if (ModelState.IsValid == false)
            {
                temp = Page();
            }
            else
            {
                if (tGame != null)
                {
                    GamesDataAcessLayer factory = new GamesDataAcessLayer(_configuration);

                    lstGames = factory.SearchGames(tGame).ToList();

                    if (lstGames.Count > 0)
                    {
                        gm = lstGames;
                        temp = Page();
                    }
                    else
                    {
                        tGame.Feedback = "Search Failed.";
                        temp = Page();
                    }
                }
                else
                {
                    temp = Page();
                }
            }
            return temp;
        }
    }
}