﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

using System.Data;
using System.Data.SqlClient;

using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Http;

namespace JN_Gamebase.Pages
{
    public class SearchModel : PageModel
    {
        [BindProperty]
        public Games tGame { get; set; }

        private readonly IConfiguration _configuration;

        GamesDataAcessLayer factory;
        public List<Games> gm { get; set; }

        public SearchModel(IConfiguration configuration)
        {
            _configuration = configuration;
            factory = new GamesDataAcessLayer(_configuration);
        }

        public void OnGet()
        {
            gm = factory.GetActiveRecords().ToList();
        }

        /*protected void btnSearch(object sender, EventArgs e)
        {
            Games temp = new Games();

            DataSet ds = temp.SearchGames_DS(tGame.GameTitle, tGame.Genre);

            gm = ds;
            dgResults.DataMember = ds.Tables[0].TableName;
            dgResults.DataBind();
        }*/
    }
}