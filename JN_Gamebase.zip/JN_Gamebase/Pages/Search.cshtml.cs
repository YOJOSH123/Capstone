﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;

using System.Data;
using System.Data.SqlClient;

using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Http;

namespace JN_Gamebase.Pages
{
    public class SearchModel : PageModel
    {
        [BindProperty]
        public Games tGame { get; set; }

        private readonly IConfiguration _configuration;

        GamesDataAcessLayer factory;
        public List<Games> gm { get; set; }

        public SearchModel(IConfiguration configuration)
        {
            _configuration = configuration;
            factory = new GamesDataAcessLayer(_configuration);
        }

        public void OnGet()
        {
            gm = factory.GetActiveRecords().ToList();
        }

        public ActionResult OnPost()
        {
            gm = factory.SearchGames(tGame).ToList();

            return Page();
        }
    }
}