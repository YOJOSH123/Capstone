﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using JN_Gamebase.Models;

using Microsoft.Extensions.Configuration;

namespace JN_Gamebase.Pages
{
    public class DeleteGameModel : PageModel
    {
        GamesDataAcessLayer factory;

        public Games tGame { get; set; }

        private readonly IConfiguration _configuration;

        public DeleteGameModel(IConfiguration configuration)
        {
            _configuration = configuration;
            factory = new GamesDataAcessLayer(_configuration);
        }

        public ActionResult OnGet(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            tGame = factory.GetOneRecord(id);

            if (tGame == null)
            {
                return NotFound();
            }
            return Page();
        }

        public ActionResult OnPost(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            factory.DeleteGame(id);

            return RedirectToPage("/Index");
        }
    }
}