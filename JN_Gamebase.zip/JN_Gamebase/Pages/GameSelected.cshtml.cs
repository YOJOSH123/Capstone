﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using JN_Gamebase.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace JN_Gamebase.Pages
{
    public class GameSelectedModel : PageModel
    {
        private readonly IConfiguration _configuration;

        [BindProperty]
        public Games tGame { get; set; }
        public GamesDataAcessLayer factory;

        public GameSelectedModel(IConfiguration configuration)
        {
            _configuration = configuration;
            factory = new GamesDataAcessLayer(_configuration);
        }

        public ActionResult OnGet(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            else
            {
                tGame = factory.GetOneRecord(id);
            }

            if (tGame == null)
            {
                return NotFound();
            }
            return Page();
        }

        public ActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            factory.UpdateGame(tGame);

            return RedirectToPage("/Index");
        }
    }
}