﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Microsoft.Extensions.Configuration;

using JN_Gamebase.Models;

namespace JN_Gamebase.Pages
{
    public class ReviewsModel : PageModel
    {
        [BindProperty]
        public Reviews wReview { get; set; }

        private readonly IConfiguration _configuration;
        public ReviewsModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {

        }

        public IActionResult OnPost()
        {
            IActionResult temp;

            if (ModelState.IsValid == false)
            {
                temp = Page();
            }
            else
            {
                if (wReview is null == false)
                {
                    ReviewDataAccessLayer factory = new ReviewDataAccessLayer(_configuration);

                    factory.Create(wReview);
                }
                temp = Page();
            }

            return temp;
        }
    }
}