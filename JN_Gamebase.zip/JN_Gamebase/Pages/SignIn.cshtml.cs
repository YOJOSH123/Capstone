﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Microsoft.Extensions.Configuration;

using JN_Gamebase.Models;

using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Http;

namespace JN_Gamebase.Pages
{
    public class SignInModel : PageModel
    {
        [BindProperty]
        public User tUser { get; set; }
        private readonly IConfiguration _configuration;

        public SignInModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
     
        }

        public IActionResult OnPost()
        {
            IActionResult temp;
            List<User> lstUser = new List<User>();

            if (ModelState.IsValid == false)
            {
                temp = Page();
            }
            else
            {
                if (tUser != null)
                {
                    UserDataAccessLayer factory = new UserDataAccessLayer(_configuration);

                    lstUser = factory.GetUserLogin(tUser).ToList();

                    if (lstUser.Count > 0)
                    {
                        HttpContext.Session.SetInt32("GameAdmin_ID", lstUser[0].UserID);
                        HttpContext.Session.SetString("GameAdmin_Email", lstUser[0].Email);
                        temp = Redirect("/Index");
                    }
                    else
                    {
                        tUser.Feedback = "Login Failed.";
                        temp = Page();
                    }
                }
                else
                {
                    temp = Page();
                }
            }
            return temp;
        }

    }
}